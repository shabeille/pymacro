import pyautogui as macro


def main():
    macro.alert('Work in Progress!', 'Macro Writer Program', 'OK')


if __name__ == '__main__':
    main()